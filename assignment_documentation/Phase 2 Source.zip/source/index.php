<?php
require("./includes/security.php");
redirect("./login.php");
?>