<link href="layout/footer.css" rel="stylesheet" type="text/css" media="all">

<footer id="footer" class="row5 wrapper"><div>
	<div>
		<h3 class="heading">Uncommon Solutions Personel Management System</h3>
		<div id="copyright">
			<p>Copyright &copy; 2019 - All Rights Reserved - Uncommon Solutions</p>
		</div>
	</div>
</div></footer>